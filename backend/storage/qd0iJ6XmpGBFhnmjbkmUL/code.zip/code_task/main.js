// Sample main.js for a TaskNet asset-backed task
// Exports an async main function that reads data.json, processes chunks, and returns a result string.
// The worker runtime is expected to place a data.json file in the current working directory before invoking main.

import fs from 'fs/promises';

/**
 * Read data.json, perform a trivial transformation, and return a string summary.
 * In a real task you could perform ML inference, data cleaning, etc.
 */
export async function main() {
  let raw;
  try {
    raw = await fs.readFile('./data.json', 'utf8');
  } catch (e) {
    return 'No data.json found';
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    return 'Invalid JSON in data.json';
  }

  // Support both object and array formats
  const items = Array.isArray(parsed) ? parsed : parsed.items ? parsed.items : [parsed];
  const count = items.length;
  const keys = new Set();
  for (const item of items) {
    if (item && typeof item === 'object') {
      Object.keys(item).forEach(k => keys.add(k));
    }
  }

  return `Processed ${count} item(s). Keys observed: ${Array.from(keys).join(', ')}`;
}

// Optional helper to run standalone for local testing
if (import.meta.url === `file://${process.argv[1]}`) {
  main().then(r => console.log(r)).catch(e => console.error(e));
}
